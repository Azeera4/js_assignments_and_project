console.log("\n Print 5 '*' Horizontally")

for (i=0; i<1; i++)
{
    c = ""
    for (j=0; j<5; j++)
    {
        c=c + "* "
    }
    console.log(c);
}

console.log("\n Print 5 '*' Vertically")
for(i=0; i<5; i++)
{
  console.log("* ")
}